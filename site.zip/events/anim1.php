<!DOCTYPE html>
<html>
<head>
	<title>Animation 1 - Mines'perium</title>
	<link rel="stylesheet" type="text/css" href="../style/style.css">
	<link rel="stylesheet" type="text/css" href="../style/style_planning.css">
	<meta charset="utf-8">
</head>
<body>	
	<img class="affiche" src="../img/events/Anim_12_03_18.jpg">
</body>
</html>