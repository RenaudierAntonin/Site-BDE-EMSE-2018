<hr>
	<div class="social-container">
		<a href="https://www.facebook.com/minesperium/" target="_blank"><img class="social" src="img/facebook_logo.svg"></a>
		<a href="snapchat.html" target="_blank"><img class="social" src="img/snapchat_logo.svg"></a>
		<a href="" target="_blank"><img class="social" src="img/youtube_logo.svg"></a>
	</div>
<hr>