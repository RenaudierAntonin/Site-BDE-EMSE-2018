	<div class="social-container">
		<p style="font-size: 10px;">Partenaire</p>
		<a href="https://www.geekstore.fr/" target="_blank"><img class="social" src="img/geekstore.png"></a>
	</div>
<hr>